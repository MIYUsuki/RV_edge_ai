#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "mqtt_client.h"
#include "snr9816.h"

static const char *TAG_GPIO = "GPIO_DETECT";

// 定义你要检测的引脚 (根据实际情况修改)
#define SENSOR_INPUT_PIN  GPIO_NUM_4

// 声明外部的 MQTT 客户端句柄 (引用你已有代码中的 mqtt_client)
extern esp_mqtt_client_handle_t mqtt_client;

/**
 * @brief GPIO 初始化配置
 */
static void gpio_input_init(void) {
    gpio_config_t io_conf = {
        .intr_type = GPIO_INTR_DISABLE,         // 轮询模式，不使用硬件中断
        .mode = GPIO_MODE_INPUT,                // 设置为输入模式
        .pin_bit_mask = (1ULL << SENSOR_INPUT_PIN), // 选择引脚
        .pull_down_en = GPIO_PULLDOWN_ENABLE,   // 启用下拉电阻 (默认保持低电平，防悬空误触)
        .pull_up_en = GPIO_PULLUP_DISABLE,      // 禁用上拉
    };
    gpio_config(&io_conf);
    ESP_LOGI(TAG_GPIO, "GPIO %d initialized as input.", SENSOR_INPUT_PIN);
}

/**
 * @brief 引脚电平轮询与 MQTT 发送任务
 */
static void gpio_detect_task(void *arg) {
    // 记录上一次的电平状态，初始假定为低电平 (0)
    int last_state = 0; 
    
    while (1) {
        // 读取当前引脚电平 (1 为高电平，0 为低电平)
        int current_state = gpio_get_level(SENSOR_INPUT_PIN);

        // 核心逻辑：只有当上一次是 0，这一次是 1 时，才认为是"触发了高电平"
        if (current_state == 1 && last_state == 0) {
            ESP_LOGI(TAG_GPIO, "检测到高电平! 正在发送 MQTT 消息...");
            
            // 确保 MQTT 客户端不为空且已连接再发送
            if (mqtt_client != NULL) {
                const char *topic = "sensor/alert";
                const char *payload = "{\"status\": \"fall_detected\"}";
                tts_play_text("您没事吧");
                
                // 发送 QoS=1 的消息保证到达
                esp_mqtt_client_publish(mqtt_client, topic, payload, 0, 1, 0);
            } else {
                ESP_LOGW(TAG_GPIO, "MQTT 客户端未就绪，放弃发送。");
            }
        }

        // 更新上一次的状态
        last_state = current_state;

        // 延时 50ms (包含两个作用：1. 释放CPU给其他任务 2. 软件按键消抖)
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}

/**
 * @brief 启动检测任务的入口函数
 */
void start_gpio_detect(void) {
    gpio_input_init();
    
    // 创建一个 FreeRTOS 任务专门用于检测
    // 栈空间给 2048 足够，优先级设为 3 (可根据实际需求调整)
    xTaskCreate(gpio_detect_task, "gpio_detect_task", 2048, NULL, 3, NULL);
}
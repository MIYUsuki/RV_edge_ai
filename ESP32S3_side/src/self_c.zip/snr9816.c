#include "driver/uart.h"
#include "snr9816.h"

// --- SNR9816TTS UART 初始化 ---
static void tts_uart_init(void) {
    uart_config_t uart_config = {
        .baud_rate = 115200,                // 模块默认波特率 [cite: 175]
        .data_bits = UART_DATA_8_BITS,      
        .parity    = UART_PARITY_DISABLE,   
        .stop_bits = UART_STOP_BITS_1,      
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    uart_driver_install(TTS_UART_NUM, 256, 0, 0, NULL, 0);
    uart_param_config(TTS_UART_NUM, &uart_config);
    uart_set_pin(TTS_UART_NUM, TTS_TXD_PIN, TTS_RXD_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
}

// --- SNR9816TTS 语音播报核心函数 ---
void tts_play_text(const char *text) {
    if (text == NULL) return;
    
    size_t text_len = strlen(text);
    if (text_len > 4000) text_len = 4000; // 单次合成不超过4K字节 [cite: 177]

    // 数据长度 = 命令字(1) + 编码参数(1) + 文本长度 [cite: 178]
    uint16_t data_len = 2 + text_len; 
    
    // 总帧长 = 帧头(1) + 长度(2) + 数据长度 [cite: 178]
    uint8_t *frame = malloc(3 + data_len);
    if (frame == NULL) return;

    frame[0] = 0xFD;                     // 帧头 [cite: 178]
    frame[1] = (data_len >> 8) & 0xFF;   // 数据长度高8位 [cite: 178]
    frame[2] = data_len & 0xFF;          // 数据长度低8位 [cite: 178]
    frame[3] = 0x01;                     // 命令字：合成播放 [cite: 178]
    frame[4] = 0x04;                     // 编码参数：0x04代表UTF-8 [cite: 178]
    
    memcpy(&frame[5], text, text_len);   // 填入UTF-8文本

    uart_write_bytes(TTS_UART_NUM, frame, 3 + data_len);
    ESP_LOGI(TAG, "Sent %d bytes to TTS module.", text_len);
    
    free(frame);
}
#include "esp_rom_uart.h"

// --- TTS 模块配置 (SNR9816TTS) ---
// 波特率默认 115200
#define TTS_UART_NUM       UART_NUM_2
#define TTS_TXD_PIN        43   // 接TTS模块的RX
#define TTS_RXD_PIN        44   // 接TTS模块的TX
extern TAG = 

static void tts_uart_init(void);
void tts_play_text(const char *text);
// UART 引脚与配置 (根据S3实际接线修改)
#define RADAR_UART_NUM     UART_NUM_1
#define RADAR_TXD_PIN      17
#define RADAR_RXD_PIN      18
#define RADAR_RX_BUF_SIZE  256
// --- TTS 模块配置 (SNR9816TTS) ---
#define TTS_UART_NUM       UART_NUM_2
#define TTS_TXD_PIN        43   // 对应TTS模块的RX脚 
#define TTS_RXD_PIN        44   // 对应TTS模块的TX脚

// --- I2S 麦克风配置 (INMP441) ---
#define I2S_PORT_NUM       I2S_NUM_0
#define I2S_WS_PIN         41
#define I2S_SCK_PIN        42
#define I2S_SD_PIN         40
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "mqtt_client.h"

// 定义你要检测的引脚 (根据实际情况修改)
#define SENSOR_INPUT_PIN  GPIO_NUM_4

// 声明外部的 MQTT 客户端句柄 (引用你已有代码中的 mqtt_client)
extern esp_mqtt_client_handle_t mqtt_client;

static void gpio_input_init(void);
static void gpio_detect_task(void *arg);
void start_gpio_detect(void);